#!/usr/bin/env python3
import os, sys, random
# This tool is for extracting next moves for a BDD-based strategy



#========================
# BDD file
#========================
class BDD:

    def __init__(self,inFile):
        self.version = None
        self.mode = None
        self.vars = ""
        self.ids = ""
        self.rootID = ""
        self.nodes = [None]
        with open(inFile,"r") as inFile:
            nodesMode = False
            for line in inFile.readlines():
                if nodesMode:
                    if line.strip()==".end":
                        pass
                    else:
                        parts = line.split(" ")
                        nodeNum = int(parts[0])
                        varID = parts[1]
                        if varID=="T":
                            varID = -1
                        else:
                            varID = int(varID)
                        index = int(parts[2])
                        trueSucc = int(parts[3])
                        elseSucc = int(parts[4])
                        assert len(self.nodes)==nodeNum
                        self.nodes.append((varID,index,trueSucc,elseSucc))
                else:
                    if line.startswith("#"):
                        pass # Comment
                    elif line.startswith(".ver "):
                        self.version = line[5:].strip()
                    elif line.startswith(".mode "):
                        self.mode = line[6:].strip()
                    elif line.startswith(".varinfo"):
                        pass
                    elif line.startswith(".nnodes"):
                        pass
                    elif line.startswith(".nvars"):
                        pass
                    elif line.startswith(".nsuppvars"):
                        pass
                    elif line.startswith(".suppvarnames"):
                        pass
                    elif line.startswith(".orderedvarnames"):
                        self.vars = line[17:].strip().split(" ")
                    elif line.startswith(".ids"):
                        self.ids = line[4:].strip()
                    elif line.startswith(".permids"):
                        pass
                    elif line.startswith(".auxids"):
                        pass
                    elif line.startswith(".nroots"):
                        if line.strip()!=".nroots 1":
                            raise Exception("Only supporting single BDDs.")
                    elif line.startswith(".rootids"):
                        self.rootID = int(line.split(" ")[1].strip())
                    elif line.startswith(".nodes"):
                        nodesMode = True
                        if self.version!="DDDMP-2.0":
                            raise Exception("Incorrect DDDMP version.")
                        elif self.mode!="A":
                            raise Exception("Incorrect mode, namely: "+mode)
                    else:
                        raise Exception("Illegal line starting: ",line)

    def setOutputVars(self,outputVarString):
        parts = outputVarString.split(" ")
        self.varsToTypeAndNumberMapper = [] # True is output
        nofInputsSoFar = 0
        nofOutputsSoFar = 0
        for i,v in enumerate(self.vars):
            if v in parts:
                self.varsToTypeAndNumberMapper.append((True,nofOutputsSoFar))
                nofOutputsSoFar += 1
            else:
                self.varsToTypeAndNumberMapper.append((False,nofInputsSoFar))
                nofInputsSoFar += 1
        if nofInputsSoFar+nofOutputsSoFar!=len(self.vars):
            raise Exception("Error: Some output vars given do not appear in the variable list")

    def printCase(self,a):
        for i,(typ,id) in enumerate(self.varsToTypeAndNumberMapper):
            if not typ:
                if i in a:
                    if a[i]:
                        print("1",end="")
                    else:
                        print("0",end="")
                else:
                    print("?",end="")
        print(" ",end="")
        for i,(typ,id) in enumerate(self.varsToTypeAndNumberMapper):
            if typ:
                if i in a:
                    if a[i]:
                        print("1",end="")
                    else:
                        print("0",end="")
                else:
                    print("?",end="")
        print("")


    def getRandomIO(self):
        """This is a function that follows a random path through the binary decision diagram.
        The difficulty is that the file format works with complemented else edges, 
        which makes thinking about BDDs quite difficult.

        Every node is labeled by: variable number, support Variable number, true success and false successor.

        Paths can be followed through the BDD as usual, and the final result needs to be complemented
        if the number of complemeneted edges followed is odd. There is only a "TRUE" node in the
        BDD, and complemented edges can be used to denote FALSE.
        
        When taking a random input/output, care needs to be taken not to go to the FALSE
        node because the input/output combination needs to be admissible. The sampling here is certainly not uniform.
        
        """
        a = {}
        currentNode = self.rootID
        while abs(currentNode)!=1:
            assert currentNode!=-1
            if currentNode<0:
                currentNode = -1*currentNode
                negated = True
            else:
                negated = False
            (idVar,supportVar,trueSucc,elseSucc) = self.nodes[currentNode]
            if (trueSucc==-1) and not negated:
                choice = False
            elif (trueSucc==1) and negated:
                choice = False
            elif (elseSucc==-1) and not negated:
                choice = True
            elif (elseSucc==1) and negated:                    
                choice = True
            else:
                choice = random.random()<0.5
            a[idVar] = choice
            if choice:
                if negated:
                    currentNode = -1*trueSucc
                else:
                    currentNode = trueSucc
            else:
                if negated:
                    currentNode = -1*elseSucc
                else:
                    currentNode = elseSucc

        self.printCase(a)
            





#========================
# Main part
#========================
inFile = ""
outVars = ""
isRandom = False
input = ""
for arg in sys.argv[1:]:
    if arg.startswith("-"):
        # Option
        if arg=="--random":
            isRandom = True
        else:
            print("Error: Did not understand the following option: ",arg)
            sys.exit(1)
    else:
        if inFile=="":
            inFile = arg
        elif outVars=="":
            outVars = arg
        elif input=="":
            input = arg
        else:
            print("Error: Too many text parameters.")
            sys.exit(1)
if inFile=="":
    print("Error: No input file name given.")
    sys.exit(1)
elif outVars=="":
    print("Error: No output variables given.")
    sys.exit(1)
elif not isRandom and input=="":
    print("Error: Either input bit assignment or \"--random\" needs to be given.")
    sys.exit(1)

bddFile = BDD(inFile)
bddFile.setOutputVars(outVars)

if isRandom:
    for i in range(100):
        bddFile.getRandomIO()
